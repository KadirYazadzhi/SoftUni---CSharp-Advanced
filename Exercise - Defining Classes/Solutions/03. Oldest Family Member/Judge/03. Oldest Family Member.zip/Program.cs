﻿using System;
using System.Linq;

namespace  DefiningClasses {
    public class StartUp {
        public static void Main() {
            Family.FamilyReader();
        }
    }
}
