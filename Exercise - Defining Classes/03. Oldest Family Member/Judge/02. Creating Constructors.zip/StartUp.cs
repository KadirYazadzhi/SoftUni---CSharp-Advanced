﻿using System;
using System.Linq;

namespace  DefiningClasses {
    public class StartUp {
        static void Main() {
            
        }
    }
}
