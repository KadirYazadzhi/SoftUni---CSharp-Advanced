using System;
using System.Linq;
using System.Collections.Generic;

namespace GenericScale {
    class StartUp {
        public static void Main(string[] args) {
            
        }
    }

}
