using System;
using System.Linq;
using System.Collections.Generic;

namespace GenericArrayCreator {
    class StartUp {
        public static void Main(string[] args) {
            
        }
    }
}
